# Running Prophet on Windows

These JAR files include an older XStream library that throws an
`InaccessibleObjectException` when loading experiments with Java 17.
The launchers use Java 8 to run this distribution of Prophet.

1. Install a Java 8 JRE or JDK if one is not already installed.
2. Run `open-editor.bat` to edit experiments or `open-viewer.bat` to view them.

The script looks for Java 8 in `JAVA8_HOME`, `JAVA_HOME`, common installation
folders, and `PATH`. For an installation in another location, set
`JAVA8_HOME` to the Java 8 installation folder (without the `bin` suffix).

Keep both BAT files and `start-prophet.ps1` in the same folder as the JARs.
Opening a JAR directly still uses the Windows Java file association,
which may point to Java 17. The launchers do not change this association.

This is a compatibility workaround for the existing binaries. We have not
updated the compiled JAR files for Java 17 because we are not the authors
of those binaries. Supporting Java 17 would require updating the dependencies
in Prophet's source code, recompiling, and validating experiment loading and saving.
