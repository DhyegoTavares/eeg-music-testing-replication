@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-prophet.ps1" -Mode editor
if errorlevel 1 pause

