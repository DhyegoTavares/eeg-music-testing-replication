param(
    [ValidateSet('editor', 'viewer')]
    [string]$Mode = 'editor'
)

$ErrorActionPreference = 'Stop'
try {
    $candidates = @()
    if ($env:JAVA8_HOME) { $candidates += Join-Path $env:JAVA8_HOME 'bin\java.exe' }
    if ($env:JAVA_HOME) { $candidates += Join-Path $env:JAVA_HOME 'bin\java.exe' }
    foreach ($rootDirectory in @($env:ProgramFiles, ${env:ProgramFiles(x86)})) {
        if (-not $rootDirectory) { continue }
        foreach ($vendor in @('Java', 'Eclipse Adoptium', 'Amazon Corretto', 'Zulu', 'Microsoft')) {
            $installationDirectory = Join-Path $rootDirectory $vendor
            $candidates += Get-ChildItem -Path "$installationDirectory\*\bin\java.exe" -ErrorAction SilentlyContinue |
                Select-Object -ExpandProperty FullName
        }
    }
    $candidates += Get-Command java.exe -All -ErrorAction SilentlyContinue |
        Select-Object -ExpandProperty Source

    $java8 = $null
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (-not (Test-Path -LiteralPath $candidate)) { continue }
        $javaProcess = New-Object System.Diagnostics.Process
        $javaProcess.StartInfo.FileName = $candidate
        $javaProcess.StartInfo.Arguments = '-version'
        $javaProcess.StartInfo.UseShellExecute = $false
        $javaProcess.StartInfo.CreateNoWindow = $true
        $javaProcess.StartInfo.RedirectStandardError = $true
        [void]$javaProcess.Start()
        $version = $javaProcess.StandardError.ReadToEnd()
        $javaProcess.WaitForExit()
        $javaProcess.Dispose()
        if ($version -match 'version "1\.8\.') { $java8 = $candidate; break }
    }
    if (-not $java8) {
        throw 'Java 8 was not found. Install a Java 8 JRE/JDK and set JAVA8_HOME to its installation folder.'
    }
    Set-Location -LiteralPath $PSScriptRoot
    Write-Host "Using Java: $java8"
    & $java8 -jar "experiment-$Mode.jar"
    exit $LASTEXITCODE
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
